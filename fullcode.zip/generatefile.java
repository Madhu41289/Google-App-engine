
 /*  Generates 411 files spanning 311MB of data
* Please Make sure to Change the path to Dataset Generation folder
 */
package dataset;

import java.io.*;
import java.math.BigInteger;
import java.security.*;
import java.util.*;

public class generatefile {

	public static void main(String[] args) throws IOException
	{
		int i;   				//Variable to keep track of no of files generated
		int oneKBFile = 0, tenKBFile = 0, hundredKBFile = 0, oneMBFile = 0, tenMBFile = 0, hundredMBFile = 0;

		for(i=0; i<411; i++)
		{
			SecureRandom rand = new SecureRandom();
			String fileName = new BigInteger(51, rand).toString(32);	// TO generate a random fileName of length 10 characters

			try
			{
				File file_Path = new File("D:\\EclipsWS\\Files\\"+ fileName + ".txt");
				file_Path.createNewFile();
				FileWriter fInsert = new FileWriter(file_Path);
				BufferedWriter bInsert = new BufferedWriter(fInsert);

				if(oneKBFile < 100)			// TO generate 100 1KB files
				{
					InsertData(bInsert, 8);
					oneKBFile++;
				}
				 else if(tenKBFile < 100)	// TO generate 100 10KB files
				{
					InsertData(bInsert, 80);
					tenKBFile++;
				}
				else if(hundredKBFile < 100)	// TO generate 100 100KB files
				{
					InsertData(bInsert, 800);
					hundredKBFile++;
				}
				else if(oneMBFile < 100)		// TO generate 100 1MB files
				{
					InsertData(bInsert, 8192);
					oneMBFile++;
				}
				else if(tenMBFile < 10)			// TO generate 10 10MB files
				{
					InsertData(bInsert, 81920);
					tenMBFile++;
				}
				else if(hundredMBFile < 1)		// TO generate one 100MB file
				{
					InsertData(bInsert, 819200);
					hundredMBFile++;
				}
				bInsert.close();
			}
			catch(IOException e)
			{
				throw(e);
			}
			System.out.println("Name of File Generated:" + fileName);
		}

	}

	public static void InsertData(BufferedWriter writer,int n) throws IOException
	{
		int MAX =0;
		while(MAX < n) {
			String data  = GetString();
			writer.write(data);
			writer.newLine();
			MAX++;
		}
	}

	public static String GetString()
	{
		char[] ch = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
		StringBuilder Data_String =  new StringBuilder();
		Random rands = new Random();

		for(int j=0; j<126; j++)	{
			char characters = ch[rands.nextInt(ch.length)];
			Data_String.append(characters);
		}
		String Generated_data = Data_String.toString();
		return Generated_data;
	}
}
