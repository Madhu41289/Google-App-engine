package com.cs553;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.memcache.MemcacheService;
import com.google.appengine.api.memcache.MemcacheServiceFactory;
public class MemCacheElements extends HttpServlet {

	/**
	 *Retrieves the file count present in cache 
	 */
	private static final long serialVersionUID = 1L;
	private MemcacheService memCacheService = MemcacheServiceFactory.getMemcacheService();
	
	public void doPost(HttpServletRequest req,HttpServletResponse resp) throws IOException
	{
		
		long TotalElements=memCacheService.getStatistics().getItemCount();
		
		resp.setContentType("text/plain");
		resp.getWriter().println("Total Elements in MemCache is: "+TotalElements);
	}
}
