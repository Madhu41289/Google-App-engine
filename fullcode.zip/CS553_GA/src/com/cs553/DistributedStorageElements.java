package com.cs553;

import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.blobstore.BlobInfo;
import com.google.appengine.api.blobstore.BlobInfoFactory;

public class DistributedStorageElements extends HttpServlet
{
	
	private static final long serialVersionUID = 1L;
    // Listing the elements of file from distributed storage 
	public void doPost(HttpServletRequest req,HttpServletResponse resp) throws IOException
	{
		List<BlobInfo> dataBlobList=new LinkedList<BlobInfo>();
		Iterator<BlobInfo> blobInfoIterator = new BlobInfoFactory().queryBlobInfos();
		while(blobInfoIterator.hasNext())
			dataBlobList.add(blobInfoIterator.next());
		resp.setContentType("text/plain");
		
		resp.getWriter().println("Total Number of Elements in Distributed storage is: "+dataBlobList.size());
	}
}
