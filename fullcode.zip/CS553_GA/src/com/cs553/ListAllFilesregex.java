package com.cs553;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

import com.google.appengine.api.blobstore.BlobInfo;
import com.google.appengine.api.blobstore.BlobInfoFactory;
import com.google.appengine.api.memcache.MemcacheService;
import com.google.appengine.api.memcache.MemcacheServiceFactory;



public class ListAllFilesregex extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	@SuppressWarnings("unused")
	private MemcacheService memCacheService = MemcacheServiceFactory
			.getMemcacheService();
	/*
	Gets all the blob keys and gets the string 
	using pattern checks in the blob files and displays all the
	filenames with that string
	*/
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		resp.setContentType("text/plain");
		String fileNameInStorage = null;
		String stringPatten = req.getParameter("regexpr");
		resp.getWriter().println(
				"The String Reg expression to search is: " + stringPatten+"\n");
		
		List<BlobInfo> dataBlobList = new LinkedList<BlobInfo>();
		Iterator<BlobInfo> blobIterator = new BlobInfoFactory()
				.queryBlobInfos();
		while (blobIterator.hasNext())
			dataBlobList.add(blobIterator.next());

		ArrayList<String> matches = new ArrayList<String>();
		
		Pattern p = Pattern.compile(stringPatten);
		
		int i;
		
		for (i = 0; i < dataBlobList.size(); i++) {

			fileNameInStorage = dataBlobList.get(i).getFilename();
			
			
			
			if (p.matcher(fileNameInStorage).matches()) {
			      matches.add(fileNameInStorage);
			    }	
					}
		resp.getWriter().println("FilaNames with matching regex");
		 for (String name : matches) {
			 resp.getWriter().println("FilaName:"+name);
	        }
		
			}

}
