package com.cs553;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.memcache.MemcacheService;
import com.google.appengine.api.memcache.MemcacheServiceFactory;

public class RemoveCache extends HttpServlet
{
	/**
	 * Deletes all the files from cache
	 */
	private static final long serialVersionUID = 1L;

	private MemcacheService memCacheService = MemcacheServiceFactory.getMemcacheService();
	
	public void doPost(HttpServletRequest req,HttpServletResponse resp) throws IOException
	{	
		memCacheService.clearAll();	
		resp.setContentType("text/plain");
		resp.getWriter().println("Removed All Files From Cache");
	}
}
