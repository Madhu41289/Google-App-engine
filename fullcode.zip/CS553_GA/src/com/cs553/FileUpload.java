package com.cs553;

import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.blobstore.BlobInfo;
import com.google.appengine.api.blobstore.BlobInfoFactory;
import com.google.appengine.api.blobstore.BlobstoreService;
import com.google.appengine.api.blobstore.BlobstoreServiceFactory;
import com.google.appengine.api.files.AppEngineFile;
import com.google.appengine.api.files.FileService;
import com.google.appengine.api.files.FileServiceFactory;
import com.google.appengine.api.memcache.MemcacheService;
import com.google.appengine.api.memcache.MemcacheServiceFactory;

@SuppressWarnings("deprecation")

public class FileUpload extends HttpServlet
{
	
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("unused")
	private BlobstoreService blobStoreService = BlobstoreServiceFactory.getBlobstoreService();
    private MemcacheService MemCacheService = MemcacheServiceFactory.getMemcacheService();
    private AppEngineFile file;
    /*
	Gets each blobkey and checks the size of file and puts the file 
	in memcache if less than 1MB and upload that blobkey file in 
	distributed storage also
	*/
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
    	long endTime=System.currentTimeMillis();
    	
    	long startTime=Long.parseLong(req.getParameter("time"));
    	res.setContentType("text/plain");
    	res.getWriter().println("Files Uploaded to Distributed Cloud Storage successfully"+"\n");
    	res.getWriter().println("Total Time taken to upload files to Distrubuted Storage is:: "+(endTime-startTime)+"ms"+"\n");
    	int i;
    	
       
        
        List<BlobInfo> dataBlobList = new LinkedList<BlobInfo>();
        Iterator<BlobInfo> blobInfoIterator = new BlobInfoFactory().queryBlobInfos();
        
        long startTimeCache=System.currentTimeMillis();
              
    	while(blobInfoIterator.hasNext())
    		dataBlobList.add(blobInfoIterator.next()); 
    
    	
    	for(i=0;i<dataBlobList.size();i++)
    	{
    		FileService fileService = FileServiceFactory.getFileService();
    		if(dataBlobList.get(i).getSize() <= 102400){
    			this.file = fileService.getBlobFile(dataBlobList.get(i).getBlobKey());
    			this.MemCacheService.put(dataBlobList.get(i).getFilename(), this.file); 
    		}
    	}
    	long endTimeCache=System.currentTimeMillis();
    	res.getWriter().println("Files uploaded to Memcache successfully"+"\n");
    	res.getWriter().println("Total Time taken to upload files to Memcache is:: "+(endTimeCache-startTimeCache)+"ms"+"\n");    	
	}
}
