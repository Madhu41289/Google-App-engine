package com.cs553;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.channels.Channels;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.blobstore.BlobInfo;
import com.google.appengine.api.blobstore.BlobInfoFactory;
import com.google.appengine.api.files.AppEngineFile;
import com.google.appengine.api.files.FileReadChannel;
import com.google.appengine.api.files.FileService;
import com.google.appengine.api.files.FileServiceFactory;
import com.google.appengine.api.memcache.MemcacheService;
import com.google.appengine.api.memcache.MemcacheServiceFactory;

@SuppressWarnings({ "serial", "deprecation" })
public class FindStringInFile extends HttpServlet {

	private MemcacheService meMCacheService = MemcacheServiceFactory.getMemcacheService();
    public void doPost(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {
    	res.setContentType("text/plain");
        String inputFile = req.getParameter("inputFile");
        String inputString = req.getParameter("inputString");
        inputString = inputString.toLowerCase();        
        AppEngineFile appEngineFile;
		appEngineFile = (AppEngineFile) meMCacheService.get(inputFile);
		
		if(appEngineFile == null){
			res.getWriter().println("File not found in MemCache" + "\n");
			
			List<BlobInfo> dataBlobList = new LinkedList<BlobInfo>();
			Iterator<BlobInfo> blobInfoIterator = new BlobInfoFactory()
					.queryBlobInfos();
			while (blobInfoIterator.hasNext())
				dataBlobList.add(blobInfoIterator.next());
			Boolean filePresent = false;
			int i;
			for (i = 0; i < dataBlobList.size(); i++) {
				String fileName = dataBlobList.get(i).getFilename();
				if (fileName.equals(inputFile)) {
					filePresent = true;

					break;
				}
				else {
					filePresent = false;

				}
		
		}
			
			if (filePresent) {
			
			res.getWriter().println(
					"File " + inputFile
							+ " is present in distributed storage"+"\n");
			FileService fService = FileServiceFactory.getFileService();
			AppEngineFile readableFile = fService.getBlobFile(dataBlobList.get(i)
					.getBlobKey());

			FileReadChannel readChannel = fService.openReadChannel(
					readableFile, false);
			BufferedReader reader = new BufferedReader(
					Channels.newReader(readChannel, "UTF8"));
			@SuppressWarnings("unused")
			FileService fileService = FileServiceFactory.getFileService();
			int flag = 0;
			String eachLine;
			List<String> strings = new ArrayList<String>();
			int c = 0;
			while((eachLine = reader.readLine()) != null){
				eachLine = eachLine.toLowerCase();
				strings.add(eachLine);
				StringTokenizer stringToken = new StringTokenizer(strings.get(c++));
				int count = stringToken.countTokens();
				for (int j = 0; j < count; j++) {
                    String s = stringToken.nextToken();                   
                    if(s.contains(inputString)){
                    	res.getWriter().println(inputString + " found in file " + inputFile + "\n");
                    	flag++;
                    	break;
                    }
				}
			}
			if(flag == 0){
		    	res.getWriter().println(inputString + " not found in file " + inputFile + "\n");
			}
			readChannel.close();

		}
			else{
				
					res.getWriter().println(
							"\n"+"File " + inputFile + " not exists in distributed storage");
				
			}
		}
		else{ 
			FileService fileService = FileServiceFactory.getFileService();
			FileReadChannel readChannel1 = fileService.openReadChannel(appEngineFile, false);
			BufferedReader bufferReader1 = new BufferedReader(Channels.newReader(readChannel1, "UTF8"));
			int flag1 = 0;
			String eachLine1;
			List<String> strings1 = new ArrayList<String>();
			int c1 = 0;
			while((eachLine1 = bufferReader1.readLine()) != null){
				eachLine1 = eachLine1.toLowerCase();
				strings1.add(eachLine1);
				StringTokenizer stringToken1 = new StringTokenizer(strings1.get(c1++));
				int count1 = stringToken1.countTokens();
				for (int i = 0; i < count1; i++) {
                    String s1 = stringToken1.nextToken();                   
                    if(s1.contains(inputString)){
                    	res.getWriter().println(inputString + " found in file " + inputFile + "\n");
                    	flag1++;
                    	break;
                    }
				}
			}
			if(flag1 == 0){
		    	res.getWriter().println(inputString + " not found in file " + inputFile + "\n");
			}
		}
  }
    
}