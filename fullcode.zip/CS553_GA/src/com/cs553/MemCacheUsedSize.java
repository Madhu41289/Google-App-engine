package com.cs553;

import java.io.IOException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.memcache.MemcacheService;
import com.google.appengine.api.memcache.MemcacheServiceFactory;

/**
 * The MemCacheUsedSizeServlet implements functionality to get utilized MemCache Size
 *
 * @author Nagarjuna
 * @version 1.0
 * @since 2014-11-05
 */
public class MemCacheUsedSize extends HttpServlet
{
	/**
	 * retrieves the total file size in cache
	 */
	
	private static final long serialVersionUID = 1L;
	private MemcacheService memCacheService=MemcacheServiceFactory.getMemcacheService();
	
	public void doPost(HttpServletRequest req,HttpServletResponse resp) throws IOException
	{
	
		long sizeinBytes=memCacheService.getStatistics().getTotalItemBytes();
		float sizeinMB =(sizeinBytes/1048576);
		resp.setContentType("text/plain");
		
		resp.getWriter().println("The Utilized Cache in MemCache: "+sizeinMB+"MB");
	}
}
