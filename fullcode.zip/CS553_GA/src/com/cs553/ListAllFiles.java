package com.cs553;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import com.google.appengine.api.blobstore.BlobInfo;
import com.google.appengine.api.blobstore.BlobInfoFactory;

public class ListAllFiles extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    /*
	Lists all the files from distributed storage
	*/
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		long startTime = System.currentTimeMillis();
		List<BlobInfo> dataBlobList = new LinkedList<BlobInfo>();
		Iterator<BlobInfo> blobInfoIterator = new BlobInfoFactory()
				.queryBlobInfos();
		while (blobInfoIterator.hasNext()){
			dataBlobList.add(blobInfoIterator.next());
		}
		resp.setContentType("text/plain");
		resp.getWriter().println("**List of All Files**"+"\n");
		for (int i = 0; i < dataBlobList.size(); i++) {
			String fileName = dataBlobList.get(i).getFilename();
			resp.getWriter().println("File Name " + i + ":" + fileName);
		}

		long endTime = System.currentTimeMillis();
		resp.getWriter().println("Total Time taken to reltrieve files list is:: "+(endTime-startTime)+"ms");		
	}

}
