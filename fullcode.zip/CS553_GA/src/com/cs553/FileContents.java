package com.cs553;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.channels.Channels;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.google.appengine.api.blobstore.BlobInfo;
import com.google.appengine.api.blobstore.BlobInfoFactory;
import com.google.appengine.api.files.AppEngineFile;
import com.google.appengine.api.files.FileReadChannel;
import com.google.appengine.api.files.FileService;
import com.google.appengine.api.files.FileServiceFactory;
import com.google.appengine.api.memcache.MemcacheService;
import com.google.appengine.api.memcache.MemcacheServiceFactory;
@SuppressWarnings({ "serial", "deprecation" })
public class FileContents extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		res.setContentType("text/plain");
		String fileName = null;
		String FileForContent = req.getParameter("FileForContent");
		res.getWriter().println(
				"The File to display contents: " + FileForContent+"\n");
		long startTimeCache = System.currentTimeMillis();
		MemcacheService memCacheService = MemcacheServiceFactory.getMemcacheService();
		AppEngineFile readableFile;
		readableFile = (AppEngineFile) memCacheService.get(FileForContent);

		if (readableFile != null) {
			FileService fService = FileServiceFactory.getFileService();
			res.getWriter()
					.println("File " + FileForContent + " is present in Memcache"+"\n");
			FileReadChannel readChannel = fService.openReadChannel(
					readableFile, false);
			BufferedReader reader = new BufferedReader(Channels.newReader(
					readChannel, "UTF8"));
			String line = null;
			res.getWriter().println("Contents of the file: "+"\n");

			while ((line = reader.readLine()) != null) {
				res.getWriter().println(line);
			}
			readChannel.close();
		} 
		
		else
		{
			res.getWriter()
			.println("File " + FileForContent + " is not present in Memcache"+"\n");
		}
		
		long endTimeCache = System.currentTimeMillis();
		
		res.getWriter().println(
				"\n"+"Total Time taken with MemCache to reltrieve file contents is:: " + (endTimeCache - startTimeCache)
						+ "ms"+"\n");
			List<BlobInfo> dataBlobList = new LinkedList<BlobInfo>();
			Iterator<BlobInfo> blobInfoIterator = new BlobInfoFactory()
					.queryBlobInfos();
			while (blobInfoIterator.hasNext())
				dataBlobList.add(blobInfoIterator.next());
			Boolean filePresent = false;
			long startTimeStorage = System.currentTimeMillis();
			int i;
			for (i = 0; i < dataBlobList.size(); i++) {
				fileName = dataBlobList.get(i).getFilename();
				if (fileName.equals(FileForContent)) {
					filePresent = true;

					break;
				}
				else {
					filePresent = false;

				}
		
		}
			
			if (filePresent) {
			FileService fService = FileServiceFactory.getFileService();
			res.getWriter().println(
					"File " + fileName
							+ " is present in distributed storage"+"\n");

			readableFile = fService.getBlobFile(dataBlobList.get(i)
					.getBlobKey());

			FileReadChannel readChannel = fService.openReadChannel(
					readableFile, false);
			BufferedReader reader = new BufferedReader(
					Channels.newReader(readChannel, "UTF8"));
			String line = null;
			res.getWriter().println("Contents of the file: "+"\n");

			while ((line = reader.readLine()) != null) {

				res.getWriter().println(line);
			}

			readChannel.close();
			
			long endTimeStorage = System.currentTimeMillis();
			res.getWriter().println(
					"\n"+"Total Time taken to reltrieve file contents without MemCache is:: " + (endTimeStorage - startTimeStorage)
							+ " ms");
			}
			
			else {
				res.getWriter().println(
						"\n"+"File " + FileForContent + " not exists in distributed storage");
			}
			

	}
}
