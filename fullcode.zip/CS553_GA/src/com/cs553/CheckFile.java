package com.cs553;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.google.appengine.api.blobstore.BlobInfo;
import com.google.appengine.api.blobstore.BlobInfoFactory;
import com.google.appengine.api.files.AppEngineFile;
import com.google.appengine.api.memcache.MemcacheService;
import com.google.appengine.api.memcache.MemcacheServiceFactory;



@SuppressWarnings("deprecation")
public class CheckFile extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
    /* Checking the file stored and fetching from respective storage system
	If the file exists in memcache  fetching file from memcache
	If the file doesnt exists in blob storage fetching file from distributed storage
	If doesnt exist in memcache and distributed storage file not found
	*/
	private MemcacheService memCacheService = MemcacheServiceFactory
			.getMemcacheService();
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		resp.setContentType("text/plain");
		String fileNameInStorage = null;
		String SearchFile = req.getParameter("SearchFile");
		resp.getWriter().println(
				"The File Name to be searched is: " + SearchFile+"\n");
		long startTimeMemCache = System.currentTimeMillis();
		
		AppEngineFile cacheFile;

		cacheFile = (AppEngineFile) memCacheService.get(SearchFile);
		Boolean filePresent = false;
		if (cacheFile != null) {
			long endTimeMemCache = System.currentTimeMillis();
			resp.getWriter().println(
					"File " + SearchFile + " exists in Memcache"+"\n");
			resp.getWriter().println(
					"Total Time taken to check the file with Mem Cache is:: "
							+ (endTimeMemCache - startTimeMemCache) + "ms"+"\n");

		} else {
			resp.getWriter().println(
					"File " + SearchFile + " not exists in Memcache"+"\n");
		}
		long startTimeDataStore = System.currentTimeMillis();
		List<BlobInfo> dataBlobList = new LinkedList<BlobInfo>();
		Iterator<BlobInfo> blobInfoIterator = new BlobInfoFactory()
				.queryBlobInfos();
		while (blobInfoIterator.hasNext())
			dataBlobList.add(blobInfoIterator.next());

		
		int i;
		
		for (i = 0; i < dataBlobList.size(); i++) {

			fileNameInStorage = dataBlobList.get(i).getFilename();

			if (fileNameInStorage.equals(SearchFile)) {
				filePresent = true;

				break;
			}

			else {
				filePresent = false;

			}
		}
		if (filePresent) {

			long endTimeDataStore = System.currentTimeMillis();
			resp.getWriter().println(
					"File " + SearchFile + " exists in distributed storage"+"\n");
			resp.getWriter().println(
					"Total Time taken to check the file without Mem Cache is:: "
							+ (endTimeDataStore - startTimeDataStore) + "ms"+"\n");
		} else {
			resp.getWriter().println(
					"File " + SearchFile + " not exists in distributed storage");
		}

	}

}
