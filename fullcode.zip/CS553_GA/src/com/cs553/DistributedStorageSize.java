package com.cs553;
import javax.servlet.http.HttpServlet;

import java.io.IOException;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.blobstore.BlobInfo;
import com.google.appengine.api.blobstore.BlobInfoFactory;

public class DistributedStorageSize extends HttpServlet 
{
	
	private static final long serialVersionUID = 1L;
 /*
 Gets the list of blob keys and gets the total size in MB
 */
	public void doPost(HttpServletRequest req,HttpServletResponse resp) throws IOException
	{
		List<BlobInfo> dataBlobList=new LinkedList<BlobInfo>();
		Iterator<BlobInfo> blobInfoIterator = new BlobInfoFactory().queryBlobInfos();
		while(blobInfoIterator.hasNext())
			dataBlobList.add(blobInfoIterator.next());
		long TotalBytes = 0;
		for(int i=0;i<dataBlobList.size();i++)
		{
			TotalBytes += dataBlobList.get(i).getSize();
		}
		resp.setContentType("text/plain");
		resp.getWriter().println("The Total Utilized Distribute Storage is: "+(TotalBytes/(1048576))+" MB");
	}
}
