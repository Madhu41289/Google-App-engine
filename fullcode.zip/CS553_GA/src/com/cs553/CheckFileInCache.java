package com.cs553;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import com.google.appengine.api.files.AppEngineFile;
import com.google.appengine.api.memcache.MemcacheService;
import com.google.appengine.api.memcache.MemcacheServiceFactory;

/**
 * The CheckFileInCacheServlet implements functionality to check whether the file
 * exists in cache
 *
 * @author Krishna
 * @version 1.0
 * @since 2014-11-05
 */
/**
	Gets the blobkey from blobinfos and searches for the filename and checks in memcache 
	 */
@SuppressWarnings("deprecation")
public class CheckFileInCache extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
private MemcacheService memCacheService = MemcacheServiceFactory
.getMemcacheService();
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		resp.setContentType("text/plain");
		
		String searchFileInCache = req.getParameter("SearchFileInCache");
		resp.getWriter().println(
				"The File Name to be searched is: " + searchFileInCache +"\n" );
		long startTimeMemCache = System.currentTimeMillis();
		
		AppEngineFile cacheFile;

		cacheFile = (AppEngineFile) memCacheService.get(searchFileInCache);
		if (cacheFile != null) {
			long endTimeMemCache = System.currentTimeMillis();
			resp.getWriter().println(
					"File " + searchFileInCache + " exists in Memcache" +"\n" );
			resp.getWriter().println(
					"Total Time taken to check the file with Mem Cache is:: "
							+ (endTimeMemCache - startTimeMemCache) + "ms" +"\n" );

		} else {
			resp.getWriter().println(
					"File " + searchFileInCache + " not exists in Memcache" +"\n" );
		}
	}
}
