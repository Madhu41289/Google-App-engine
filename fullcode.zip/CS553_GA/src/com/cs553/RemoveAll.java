package com.cs553;

import javax.servlet.http.HttpServlet;

import java.io.IOException;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.appengine.api.blobstore.BlobInfo;
import com.google.appengine.api.blobstore.BlobInfoFactory;

import com.google.appengine.api.blobstore.BlobstoreService;
import com.google.appengine.api.blobstore.BlobstoreServiceFactory;

import com.google.appengine.api.memcache.MemcacheService;
import com.google.appengine.api.memcache.MemcacheServiceFactory;

/**
 * The RemoveAllServlet implements functionality to remove all files from cache and data storage
 *
 * @author Nagarjuna
 * @version 1.0
 * @since 2014-11-05
 */
public class RemoveAll extends HttpServlet
{
	/**
	 *Removes all files from memcache and distributed storage 
	 */
	private static final long serialVersionUID = 1L;
	private BlobstoreService blobStoreService=BlobstoreServiceFactory.getBlobstoreService();
	private MemcacheService memCacheService=MemcacheServiceFactory.getMemcacheService();
	
	public void doPost(HttpServletRequest req,HttpServletResponse resp) throws IOException
	{
		resp.setContentType("text/plain");
		
		if(memCacheService.getStatistics().getItemCount()>0)
		{
			memCacheService.clearAll();
			resp.getWriter().println("All Items Cleared in MemCache"+"\n");
		}
		else
		{
			resp.getWriter().println("No items in MemCache to delete"+"\n");
		}
		
		List<BlobInfo> dataBlobList = new LinkedList<BlobInfo>();
		Iterator<BlobInfo> blobIterator = new BlobInfoFactory().queryBlobInfos();
		
		while(blobIterator.hasNext())
			dataBlobList.add(blobIterator.next());
		if(!dataBlobList.isEmpty())
		{
			for(int i=0;i<dataBlobList.size();i++)
	        {
				blobStoreService.delete(dataBlobList.get(i).getBlobKey());
	        }
		
			resp.getWriter().println("\n"+"All items Cleared in Distributed Storage" );
		}
		else
		{
			resp.getWriter().println("\n"+"No items in Distributed Storage to delete" );
		}
		
	}
}
