package com.cs553;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import com.google.appengine.api.blobstore.BlobInfo;
import com.google.appengine.api.blobstore.BlobInfoFactory;

/**
 * The CheckFileInStorageServlet implements functionality to check whether the file
 * exists in  data storage
 *
 * @author Krishna
 * @version 1.0
 * @since 2014-11-05
 */
/**
	 * Checks the files in blob info and displays the whether file exists
	 */
public class CheckFileInStorage extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String fileNameInStorage = null;
		String searchFileInStorage = req.getParameter("SearchFileInStorage");
		resp.getWriter().println("The File Name to be searched in Storage is: " + searchFileInStorage +"\n");
		Boolean filePresent = false;
		long startTimeDataStore = System.currentTimeMillis();
		List<BlobInfo> dataBlobList = new LinkedList<BlobInfo>();
		Iterator<BlobInfo> blobInfoIterator = new BlobInfoFactory()
				.queryBlobInfos();
		while (blobInfoIterator.hasNext())
			dataBlobList.add(blobInfoIterator.next());

		resp.setContentType("text/plain");
		int i;
		
		for (i = 0; i < dataBlobList.size(); i++) {

			fileNameInStorage = dataBlobList.get(i).getFilename();

			if (fileNameInStorage.equals(searchFileInStorage)) {
				filePresent = true;

				break;
			}

			else {
				filePresent = false;

			}
		}
		if (filePresent) {

			long endTimeDataStore = System.currentTimeMillis();
			resp.getWriter().println(
					"File " + searchFileInStorage + " exists in distributed storage" +"\n");
			resp.getWriter().println(
					"Total Time taken to check the file without Mem Cache is:: "
							+ (endTimeDataStore - startTimeDataStore) + "ms" +"\n");
		} else {
			resp.getWriter().println(
					"File " + searchFileInStorage + " not exists in distributed storage");
		}

	}

}
